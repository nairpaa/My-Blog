import{i}from"./index.hIESyhSu.js";i();
